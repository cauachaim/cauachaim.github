export default function NotFound(){
    return (
        <h1>404</h1>
    )
}