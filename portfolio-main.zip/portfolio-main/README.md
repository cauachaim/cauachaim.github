# Portfólio

Portfólio desenvolvido em React, design e desenvolvimento realizado por mim.

### Tecnologias e bibliotecas utilizadas:

- React
- Tailwind
- Vite
- Vercel
- Fontawesome

